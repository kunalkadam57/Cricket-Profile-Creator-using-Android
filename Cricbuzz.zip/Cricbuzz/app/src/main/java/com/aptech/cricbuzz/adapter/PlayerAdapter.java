package com.aptech.cricbuzz.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.aptech.cricbuzz.R;
import com.aptech.cricbuzz.database.DatabaseHelper;
import com.aptech.cricbuzz.fragment.AddPlayerFragment;
import com.aptech.cricbuzz.pojo.CricbuzzPojo;

import java.util.List;
import java.util.Random;

public class PlayerAdapter extends RecyclerView.Adapter<PlayerAdapter.PlayerHolder>{

    private android.content.Context context;
    Animation animMoving;
    private int lastPosition = -1;
    private List<CricbuzzPojo> mListPlayers;
    private OnItemClickListener mlistener;

    public interface OnItemClickListener{
        void onItemClick(int position,int id);
        void onDeleteClick(int position,int id);
        void onEditClick(int position,int id);
    }

    public void setOnClickListener(OnItemClickListener listener){
        mlistener = listener;
    }

    private DatabaseHelper dbHelper;

    private AddPlayerFragment addPlayerFragment;



    public PlayerAdapter(List<CricbuzzPojo> listPlayers) {

        mListPlayers = listPlayers;
    }


    @NonNull
    @Override
    public PlayerAdapter.PlayerHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_player_list, parent, false);
        return new PlayerHolder(itemView,mlistener);

    }

    @Override
    public void onBindViewHolder(@NonNull PlayerHolder holder, int position) {
        CricbuzzPojo cricbuzzPojo = mListPlayers.get(position);
        holder.parentLayout.setTag(cricbuzzPojo.getId());
        holder.tv_FullName.setText(cricbuzzPojo.getFirstname() + " " + cricbuzzPojo.getLastname());

        setAnimation(holder.tv_FullName,position);

    }

    @Override
    public int getItemCount() {
        return mListPlayers.size();
    }

//


    public class PlayerHolder extends RecyclerView.ViewHolder {
        private TextView tv_FullName;
        private ImageButton edit_player_btn;
        private ImageButton delete_player_btn;
        LinearLayout parentLayout;




        public PlayerHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);
            tv_FullName = itemView.findViewById(R.id.player_list_item_tv_name);
            edit_player_btn = itemView.findViewById(R.id.player_edit_btn);
            delete_player_btn = itemView.findViewById(R.id.player_delete_btn);

            parentLayout = itemView.findViewById(R.id.constraint_layout);

            itemView.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view){
                    if(listener!=null){
                        int position=getAdapterPosition();
                        if(position!=RecyclerView.NO_POSITION){
                            listener.onItemClick(position,Integer.parseInt(parentLayout.getTag().toString()));
                        }
                    }
                }
            });

            delete_player_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(listener!=null){
                        int position=getAdapterPosition();
                        if(position!=RecyclerView.NO_POSITION){
                            listener.onDeleteClick(position,Integer.parseInt(parentLayout.getTag().toString()));
                        }
                    }
                }
            });

            edit_player_btn.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    if(listener!=null){
                        int position=getAdapterPosition();
                        if(position!=RecyclerView.NO_POSITION){
                            listener.onEditClick(position,Integer.parseInt(parentLayout.getTag().toString()));
                        }
                    }
                }
            });

        }



    }

   private void setAnimation(View viewToAnimate, int position) {
    if (position > lastPosition) {
        ScaleAnimation anim = new ScaleAnimation(0.0f, 1.0f, 0.0f, 1.0f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        anim.setDuration(new Random().nextInt(501));
        viewToAnimate.startAnimation(anim);
        lastPosition = position;
    }
}


}

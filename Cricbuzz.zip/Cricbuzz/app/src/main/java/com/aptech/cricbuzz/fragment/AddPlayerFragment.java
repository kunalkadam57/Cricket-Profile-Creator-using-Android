package com.aptech.cricbuzz.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.aptech.cricbuzz.pojo.CricbuzzPojo;
import com.aptech.cricbuzz.database.DatabaseHelper;
import com.aptech.cricbuzz.R;
import com.aptech.cricbuzz.utility.Utility;

import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class AddPlayerFragment extends Fragment implements View.OnClickListener {
    private TextView add_player_details_tv;
    private EditText fname_et;
    private EditText lname_et;
    private EditText age_et;
    private EditText batting_order_et;
    private EditText runs_scored_et;
    private EditText hcentury_et;
    private EditText century_et;
    private Button save_btn;

    Animation Animmove;

    private String mode;
    private int id;

    private CricbuzzPojo cricbuzzPojo;
    private View view = null;
    private RecyclerView rvPlayers;

    private DatabaseHelper dbHelper;

    private android.content.Context context;

    private List<CricbuzzPojo> mListPlayers;


    public AddPlayerFragment(String mode) {
        this.mode = mode;
        // Required empty public constructor
    }

    public AddPlayerFragment(String mode, int id) {
        this.mode = mode;
        this.id = id;
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        super.onCreateView(inflater, container, savedInstanceState);
        view = inflater.inflate(R.layout.fragment_add_player, null);
        initViews();
        iniListeners();
        initDatabase();
        if (Utility.modeeditPlayer.equals(mode))
            populateData();
        return view;

    }

    private void populateData() {
        cricbuzzPojo = dbHelper.getPlayer(id);
        fname_et.setText(cricbuzzPojo.getFirstname());
        lname_et.setText(cricbuzzPojo.getLastname());
        age_et.setText(cricbuzzPojo.getAge());
        batting_order_et.setText(cricbuzzPojo.getBatting_order());
        runs_scored_et.setText(cricbuzzPojo.getTotal_runs_scored());
        hcentury_et.setText(cricbuzzPojo.getHalf_centuries());
        century_et.setText(cricbuzzPojo.getCenturies());
    }

    private void iniListeners() {
        save_btn.setOnClickListener(this);
    }

    private void initViews() {
        add_player_details_tv = view.findViewById(R.id.add_player_details_tv);
        Animmove = AnimationUtils.loadAnimation(getActivity(),
                R.anim.move2);
        add_player_details_tv.startAnimation(Animmove);

        fname_et = view.findViewById(R.id.add_player_fname_et);
        lname_et = view.findViewById(R.id.add_player_lname_et);
        age_et = view.findViewById(R.id.add_player_age_et);
        batting_order_et = view.findViewById(R.id.add_player_bo_et);
        runs_scored_et = view.findViewById(R.id.add_player_rs_et);
        hcentury_et = view.findViewById(R.id.add_player_hcentury_et);
        century_et = view.findViewById(R.id.add_player_century_et);
        save_btn = view.findViewById(R.id.save_player_btn);

        if (Utility.modeeditPlayer.equals(mode)) {
            save_btn.setText("  Update Player  ");
            add_player_details_tv.setText("Edit Player Details");
        } else if (Utility.modeaddplayer.equals(mode)) {
            add_player_details_tv.setText("Add Player Details");

            int a=10;
        }

        age_et.setInputType(InputType.TYPE_CLASS_NUMBER);
        batting_order_et.setInputType(InputType.TYPE_CLASS_NUMBER);
        runs_scored_et.setInputType(InputType.TYPE_CLASS_NUMBER);
        hcentury_et.setInputType(InputType.TYPE_CLASS_NUMBER);
        century_et.setInputType(InputType.TYPE_CLASS_NUMBER);
    }

    private void initDatabase() {
        dbHelper = new DatabaseHelper(getContext());
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {

            case R.id.save_player_btn:
                if (fname_et.length() == 0) {
                    fname_et.requestFocus();
                    fname_et.setError("FIELD CANNOT BE EMPTY");
                } else if (lname_et.length() == 0) {
                    lname_et.requestFocus();
                    lname_et.setError("FIELD CANNOT BE EMPTY");
                } else if (age_et.length() == 0 || Integer.parseInt(age_et.getText().toString()) > 100 ||
                        Integer.parseInt(age_et.getText().toString()) < 1) {
                    age_et.requestFocus();
                    age_et.setError("FIELD CANNOT BE EMPTY OR LESS THAN 1 OR GREATER THAN 100");
                } else if (batting_order_et.length() == 0 || Integer.parseInt(batting_order_et.getText().toString()) > 11
                ) {
                    batting_order_et.requestFocus();
                    batting_order_et.setError("FIELD CANNOT BE EMPTY OR LESS THAN 1 OR GREATER THAN 11");
                } else if (runs_scored_et.length() == 0) {
                    runs_scored_et.requestFocus();
                    runs_scored_et.setError("FIELD CANNOT BE EMPTY");
                } else if (hcentury_et.length() == 0) {
                    hcentury_et.requestFocus();
                    hcentury_et.setError("FIELD CANNOT BE EMPTY");
                } else if (century_et.length() == 0) {
                    century_et.requestFocus();
                    century_et.setError("FIELD CANNOT BE EMPTY");
                } else {
                    if (Utility.modeaddplayer.equals(mode)) {
                        long playerId = dbHelper.addPlayer(getValues());
                        if (playerId != 0) {
                            Toast.makeText(getActivity(), "player created with id: " + playerId, Toast.LENGTH_LONG).show();
                        }
                        MainFragment mainFragment = new MainFragment();
                        FragmentManager manager = getActivity().getSupportFragmentManager();
                        FragmentTransaction transaction = manager.beginTransaction();
                        transaction.setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
                        transaction.replace(R.id.main_fl_container, mainFragment, mainFragment.getTag());
                        for (int i = 0; i < manager.getBackStackEntryCount(); ++i) {
                            manager.popBackStack();
                        }
                        transaction.commit();
                    }
                    else if(Utility.modeeditPlayer.equals(mode)){
                        int ser =dbHelper.editPlayer(getValues());
                        if(ser>0){
                            Toast.makeText(getActivity(), "player updated with id:" + id, Toast.LENGTH_LONG).show();
                        }
                        MainFragment mainFragment = new MainFragment();
                        FragmentManager manager = getActivity().getSupportFragmentManager();
                        FragmentTransaction transaction = manager.beginTransaction();
                        transaction.setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
                        transaction.replace(R.id.main_fl_container, mainFragment, mainFragment.getTag());
                        for (int i = 0; i < manager.getBackStackEntryCount(); ++i) {
                            manager.popBackStack();
                        }
                        transaction.commit();
                    }
                    break;


                }
        }


    }

    private CricbuzzPojo getValues() {
        CricbuzzPojo cricbuzzPojo = new CricbuzzPojo();
        if(Utility.modeeditPlayer.equals(mode))
            cricbuzzPojo.setId(id);
        cricbuzzPojo.setFirstname(fname_et.getText().toString().trim());
        cricbuzzPojo.setLastname(lname_et.getText().toString().trim());
        cricbuzzPojo.setAge(age_et.getText().toString().trim());
        cricbuzzPojo.setBatting_order(batting_order_et.getText().toString().trim());
        cricbuzzPojo.setTotal_runs_scored(runs_scored_et.getText().toString().trim());
        cricbuzzPojo.setHalf_centuries(hcentury_et.getText().toString().trim());
        cricbuzzPojo.setCenturies(century_et.getText().toString().trim());

        return cricbuzzPojo;
    }
}

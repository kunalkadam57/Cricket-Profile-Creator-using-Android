package com.aptech.cricbuzz.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.aptech.cricbuzz.utility.Utility;
import com.aptech.cricbuzz.pojo.CricbuzzPojo;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int Database_version=1;

    public DatabaseHelper(@Nullable Context context) {
        super(context, Utility.Database_name, null, Database_version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String CREATE_TABLE_All_Players = "CREATE TABLE "
                + Utility.key_table_name + " ("
                + Utility.key_player_id + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + Utility.key_first_name + " VARCHAR(200), "
                + Utility.key_last_name + " VARCHAR(200), "
                + Utility.key_age + " VARCHAR(200),"
                + Utility.key_batting_order + " VARCHAR(200),"
                + Utility.key_total_runs_scored + " VARCHAR(200),"
                + Utility.key_half_century + " VARCHAR(200),"
                + Utility.key_century + " VARCHAR(200))";
        sqLiteDatabase.execSQL(CREATE_TABLE_All_Players);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public long addPlayer(CricbuzzPojo cricbuzzPojo){
        long playerId;
        SQLiteDatabase db = getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(Utility.key_first_name,cricbuzzPojo.getFirstname());
        contentValues.put(Utility.key_last_name, cricbuzzPojo.getLastname());
        contentValues.put(Utility.key_age,cricbuzzPojo.getAge());
        contentValues.put(Utility.key_batting_order,cricbuzzPojo.getBatting_order());
        contentValues.put(Utility.key_total_runs_scored,cricbuzzPojo.getTotal_runs_scored());
        contentValues.put(Utility.key_half_century,cricbuzzPojo.getHalf_centuries());
        contentValues.put(Utility.key_century,cricbuzzPojo.getCenturies());

        playerId=db.insert(Utility.key_table_name,null,contentValues);
        db.close();
        return playerId;
    }

    public int editPlayer(CricbuzzPojo cricbuzzPojo){
        int numOfRows;
        SQLiteDatabase db= getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Utility.key_player_id,cricbuzzPojo.getId());

        contentValues.put(Utility.key_first_name,cricbuzzPojo.getFirstname());
        contentValues.put(Utility.key_last_name, cricbuzzPojo.getLastname());
        contentValues.put(Utility.key_age,cricbuzzPojo.getAge());
        contentValues.put(Utility.key_batting_order,cricbuzzPojo.getBatting_order());
        contentValues.put(Utility.key_total_runs_scored,cricbuzzPojo.getTotal_runs_scored());
        contentValues.put(Utility.key_half_century,cricbuzzPojo.getHalf_centuries());
        contentValues.put(Utility.key_century,cricbuzzPojo.getCenturies());

        numOfRows=db.update(Utility.key_table_name,contentValues,Utility.key_player_id +" = ?",new String[]{String.valueOf(cricbuzzPojo.getId())});
        db.close();
        return numOfRows;
    }

    public int deletePlayer(int id){
        String key= Integer.toString(id);
        SQLiteDatabase db= getWritableDatabase();
        int numOfRow=db.delete(Utility.key_table_name,Utility.key_player_id+" = ?",new String[]{key});
        db.close();
        return numOfRow;
    }

    public List<CricbuzzPojo> getPlayers(){
        List<CricbuzzPojo> playersList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(Utility.key_table_name, null,null,null,null,null,null);

        if(cursor!=null && cursor.moveToFirst()){
            do{
                CricbuzzPojo cricbuzzPojo = new CricbuzzPojo();
                cricbuzzPojo.setId(cursor.getInt(cursor.getColumnIndex(Utility.key_player_id)));
                cricbuzzPojo.setFirstname(cursor.getString(cursor.getColumnIndex(Utility.key_first_name)));
                cricbuzzPojo.setLastname(cursor.getString(cursor.getColumnIndex(Utility.key_last_name)));
                cricbuzzPojo.setAge(cursor.getString(cursor.getColumnIndex(Utility.key_age)));
                cricbuzzPojo.setBatting_order(cursor.getString(cursor.getColumnIndex(Utility.key_batting_order)));
                cricbuzzPojo.setTotal_runs_scored(cursor.getString(cursor.getColumnIndex(Utility.key_total_runs_scored)));
                cricbuzzPojo.setHalf_centuries(cursor.getString(cursor.getColumnIndex(Utility.key_half_century)));
                cricbuzzPojo.setCenturies(cursor.getString(cursor.getColumnIndex(Utility.key_century)));

                playersList.add(cricbuzzPojo);
            }while (cursor.moveToNext());
        }
        return playersList;
    }

    public CricbuzzPojo getPlayer(int id){
        CricbuzzPojo cricbuzzPojo=new CricbuzzPojo();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor=db.rawQuery("Select* from "+Utility.key_table_name+ " where "+Utility.key_player_id+"='"+id+"'",null);
        if(cursor!=null&&cursor.moveToFirst()){
            do{
                cricbuzzPojo.setId(cursor.getInt(cursor.getColumnIndex(Utility.key_player_id)));
                cricbuzzPojo.setFirstname(cursor.getString(cursor.getColumnIndex(Utility.key_first_name)));
                cricbuzzPojo.setLastname(cursor.getString(cursor.getColumnIndex(Utility.key_last_name)));
                cricbuzzPojo.setAge(cursor.getString(cursor.getColumnIndex(Utility.key_age)));
                cricbuzzPojo.setBatting_order(cursor.getString(cursor.getColumnIndex(Utility.key_batting_order)));
                cricbuzzPojo.setTotal_runs_scored(cursor.getString(cursor.getColumnIndex(Utility.key_total_runs_scored)));
                cricbuzzPojo.setHalf_centuries(cursor.getString(cursor.getColumnIndex(Utility.key_half_century)));
                cricbuzzPojo.setCenturies(cursor.getString(cursor.getColumnIndex(Utility.key_century)));
            }while (cursor.moveToNext());
        }
        return cricbuzzPojo;
    }


}

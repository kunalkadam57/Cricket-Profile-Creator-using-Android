package com.aptech.cricbuzz.pojo;

import java.util.List;

public class CricbuzzPojo  {

    private String firstname;
    private String lastname;
    private int id;
    private String  age;
    private String batting_order;
    private String total_runs_scored;
    private String half_centuries;
    private String centuries;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public  String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getBatting_order() {
        return batting_order;
    }

    public void setBatting_order(String batting_order) {
        this.batting_order = batting_order;
    }

    public String getTotal_runs_scored() {
        return total_runs_scored;
    }

    public void setTotal_runs_scored(String total_runs_scored) {
        this.total_runs_scored = total_runs_scored;
    }

    public String getHalf_centuries() {
        return half_centuries;
    }

    public void setHalf_centuries(String half_centuries) {
        this.half_centuries = half_centuries;
    }

    public String getCenturies() {
        return centuries;
    }

    public void setCenturies(String centuries) {
        this.centuries = centuries;
    }
}

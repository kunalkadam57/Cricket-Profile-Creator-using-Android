package com.aptech.cricbuzz.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.aptech.cricbuzz.pojo.CricbuzzPojo;
import com.aptech.cricbuzz.database.DatabaseHelper;
import com.aptech.cricbuzz.R;


public class ViewPlayerInformation extends Fragment {

    private DatabaseHelper dbHelper;
    private TextView Player_profile_tv,Playerfname_tv,Playerfnamevalue_tv,Playerlname_tv,Playerlnamevalue_tv,Player_age_tv,Player_agevalue_tv,Player_bo_tv,Player_bovalue_tv,
            Player_trs_tv,Player_trsvalue_tv,Player_hcentury_tv,Player_hcenturyvalue_tv,Player_century_tv,
            Player_centuryvalue_tv;
    private int id;
    Animation blinking;
    private CricbuzzPojo cricbuzzPojo;

    public ViewPlayerInformation(int id) {
        this.id=id;
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_view_player_information, container, false);
        initViews(view);
        initDatabase();
        populateData();
        return view;
    }

    private void populateData() {
        cricbuzzPojo= (CricbuzzPojo) dbHelper.getPlayer(id);

        Playerfnamevalue_tv.setText("  "+cricbuzzPojo.getFirstname());
        Playerlnamevalue_tv.setText("  "+cricbuzzPojo.getLastname());
        Player_agevalue_tv.setText("  "+cricbuzzPojo.getAge());
        Player_bovalue_tv.setText("  "+cricbuzzPojo.getBatting_order());
        Player_trsvalue_tv.setText("  "+cricbuzzPojo.getTotal_runs_scored());
        Player_hcenturyvalue_tv.setText("  "+cricbuzzPojo.getHalf_centuries());
        Player_centuryvalue_tv.setText("  "+cricbuzzPojo.getCenturies());

    }

    private void initDatabase() {
        dbHelper = new DatabaseHelper(getContext());
    }

    private void initViews(View view) {
        Player_profile_tv=view.findViewById(R.id.player_profile_tv);
        blinking = AnimationUtils.loadAnimation(getActivity(),
                R.anim.blink);
        Player_profile_tv.startAnimation(blinking);

        Playerfname_tv=view.findViewById(R.id.player_fname_tv);
        Playerlname_tv=view.findViewById(R.id.player_lname_tv);
        Player_age_tv=view.findViewById(R.id.player_age_tv);
        Player_bo_tv=view.findViewById(R.id.player_batting_order_tv);
        Player_trs_tv=view.findViewById(R.id.player_trs_tv);
        Player_hcentury_tv=view.findViewById(R.id.player_hcentury_tv);
        Player_century_tv=view.findViewById(R.id.player_century_tv);

        Playerfnamevalue_tv=view.findViewById(R.id.player_fname_value_tv);
        Playerlnamevalue_tv=view.findViewById(R.id.player_lname_value_tv);
        Player_agevalue_tv=view.findViewById(R.id.player_age_value_tv);
        Player_bovalue_tv=view.findViewById(R.id.player_batting_order_value_tv);
        Player_trsvalue_tv=view.findViewById(R.id.player_trs_value_tv);
        Player_hcenturyvalue_tv=view.findViewById(R.id.player_hcentury_value_tv);
        Player_centuryvalue_tv=view.findViewById(R.id.player_century_value_tv);
    }

}

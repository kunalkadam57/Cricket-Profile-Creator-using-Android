package com.aptech.cricbuzz.utility;

public class Utility {

    public static  String modeaddplayer="Add";
    public static String modeeditPlayer="Edit";

    public static String Database_name="Cricbuzz";
    public static String key_table_name="All_Players";
    public static String key_player_id="_id";
    public static  String key_first_name="fname";
    public static  String key_last_name="lname";
    public static  String key_age="age";
    public static  String key_batting_order="batting_order";
    public static  String key_total_runs_scored="total_runs_scored";
    public static  String key_half_century="half_century";
    public static  String key_century="century";
}

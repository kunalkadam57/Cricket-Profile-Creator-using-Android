package com.aptech.cricbuzz.fragment;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.aptech.cricbuzz.pojo.CricbuzzPojo;
import com.aptech.cricbuzz.database.DatabaseHelper;
import com.aptech.cricbuzz.adapter.PlayerAdapter;
import com.aptech.cricbuzz.R;
import com.aptech.cricbuzz.utility.Utility;

import java.util.List;

public class MainFragment extends Fragment implements View.OnClickListener{

    private TextView app_name_tv;
    private RecyclerView rvPlayers;
    private Button add_player_btn;

    private List<CricbuzzPojo> listPlayers;
    private View view =null;
    private DatabaseHelper dbHelper;
    private PlayerAdapter playerAdapter;
    Animation Slidedown;


    public MainFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        super.onCreateView(inflater, container, savedInstanceState);
        view = inflater.inflate(R.layout.fragment_main,null);
        initViews();
        initListeners();
        initDb();
        populateData();

        return view;
    }

    private void initListeners(){

        add_player_btn.setOnClickListener(this);

//         onDeleteListener deleteListener;
//        onEditListener editListener;
//        onClickView  clickview;

    }

    private void initViews() {
        app_name_tv = this.view.findViewById(R.id.tv_all_players);

        Slidedown = AnimationUtils.loadAnimation(getActivity(),
                R.anim.slidedown);
        app_name_tv.startAnimation(Slidedown);
        rvPlayers = this.view.findViewById(R.id.rv_players);
        add_player_btn = this.view.findViewById(R.id.add_player_btn);


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.add_player_btn:
                loadAddPlayerFragment(Utility.modeaddplayer);
                break;


        }

    }


    private void initDb(){
        dbHelper = new DatabaseHelper(getActivity());
    }

    private void populateData() {
         listPlayers = dbHelper.getPlayers();
        PlayerAdapter playerAdapter = new PlayerAdapter(listPlayers);
        playerAdapter.notifyDataSetChanged();
        rvPlayers.setLayoutManager(new LinearLayoutManager(getActivity()));
        rvPlayers.setAdapter(playerAdapter);
        playerAdapter.setOnClickListener(new PlayerAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position, int id) {
                loadViewPlayerFragment(id);
            }

            @Override
            public void onDeleteClick(int position, int id) {
                deletePlayer(position,id);
            }

            @Override
            public void onEditClick(int position, int id) {
                loadAddPlayerFragment(Utility.modeeditPlayer,id);
            }
        });

    }

    private void loadViewPlayerFragment(int id) {
        FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        fragmentTransaction.setCustomAnimations(android.R.anim.fade_out,android.R.anim.fade_in);
        ViewPlayerInformation viewPlayerInformation=new ViewPlayerInformation(id);
        fragmentTransaction.replace(R.id.main_fl_container,viewPlayerInformation,viewPlayerInformation.getTag());
        fragmentTransaction.addToBackStack(viewPlayerInformation.getTag());
        fragmentTransaction.commit();
    }

    private void loadAddPlayerFragment(String mode) {
        FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        fragmentTransaction.setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
        AddPlayerFragment addPlayerFragment=new AddPlayerFragment(mode);
        fragmentTransaction.replace(R.id.main_fl_container,addPlayerFragment,addPlayerFragment.getTag());
        fragmentTransaction.addToBackStack(addPlayerFragment.getTag());
        fragmentTransaction.commit();
    }
    private void loadAddPlayerFragment(String mode, int id) {
        FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        fragmentTransaction.setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
        AddPlayerFragment addPlayerFragment=new AddPlayerFragment(mode,id);
        fragmentTransaction.replace(R.id.main_fl_container,addPlayerFragment,addPlayerFragment.getTag());
        fragmentTransaction.addToBackStack(addPlayerFragment.getTag());
        fragmentTransaction.commit();
    }

    private void deletePlayer(int position, final int id) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Confirm Delete Player ?");
        builder.setMessage("Player having id "+id+" to be deleted");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(getActivity(),"Player deleted with id: "+id,Toast.LENGTH_LONG).show();
                int numOfRow=dbHelper.deletePlayer(id);
                if(numOfRow>0){
                    populateData();
                }
            }
        });
        builder.setNegativeButton("No",null);
        builder.setCancelable(false);
        AlertDialog alertDialog=builder.create();
        alertDialog.show();
    }




}
